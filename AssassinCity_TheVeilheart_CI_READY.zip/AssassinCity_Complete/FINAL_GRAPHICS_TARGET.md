# Final graphics target

The game's visual benchmark is Assassin's Creed Identity's mobile 3D presentation:
- grounded humanoid proportions
- readable silhouettes
- dense historical city streets and rooftops
- warm/cool cinematic lighting contrast
- layered materials and readable architecture
- contextual third-person camera

All game content remains original. No Ubisoft meshes, textures, animation files, audio, or other extracted assets are included.

The current self-contained build uses procedural geometry/materials so it remains portable. Replacing these generators with authored PBR meshes and skeletal clips is the final art-production step for a higher-fidelity release build.
