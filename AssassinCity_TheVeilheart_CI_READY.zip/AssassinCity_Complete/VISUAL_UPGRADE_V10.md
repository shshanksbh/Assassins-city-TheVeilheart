# Visual Upgrade v10

The v10 target is the original game's high-quality mobile 3D presentation, using Assassin's Creed Identity only as a visual/gameplay reference.

Changes in this pass:
- Godot Mobile renderer selected instead of Compatibility.
- ACES tonemapping, stronger sky gradient, height fog, glow and warm/cool lighting balance.
- Directional shadow distance increased for rooftop traversal.
- Denser city silhouettes: parapets, window bays, awnings, rooftop chimneys, facade strips and market structures.
- Responsive mobile HUD so controls remain usable across phone aspect ratios.
- Android ARM64 export preset retained.

Still required for a true final visual target:
- authored rigged humanoid meshes
- PBR texture sets
- authored skeletal animations
- high-detail weapon/environment meshes
- authored VFX and audio
- real-device profiling
