extends Node3D
## Qasr-Nadir final-world prototype.
## Original procedural assets are used so the project remains self-contained.
## Designed as a mobile-friendly foundation for detailed authored assets.

var player: Node3D
var rng := RandomNumberGenerator.new()

const CITY_RADIUS := 7
const BLOCK := 11.0

func _ready():
	rng.seed = 81731
	player = get_node_or_null("Player")
	_build_world()

func mat(color: Color, roughness := 0.72, metallic := 0.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = roughness
	m.metallic = metallic
	return m

func box(parent: Node, size: Vector3, pos: Vector3, material: Material, collision := false):
	var mesh := MeshInstance3D.new()
	var b := BoxMesh.new()
	b.size = size
	mesh.mesh = b
	mesh.position = pos
	mesh.material_override = material
	parent.add_child(mesh)
	if collision:
		var body := StaticBody3D.new()
		body.position = pos
		var cs := CollisionShape3D.new()
		var shape := BoxShape3D.new()
		shape.size = size
		cs.shape = shape
		body.add_child(cs)
		parent.add_child(body)
	return mesh

func _build_world():
	# Ground
	var ground_mat := mat(Color("#81796b"), 0.95)
	box(self, Vector3(170, 0.6, 170), Vector3(0,-0.3,0), ground_mat, true)

	# Street grid
	var street_mat := mat(Color("#3b3936"), 0.92)
	for i in range(-CITY_RADIUS, CITY_RADIUS + 1):
		box(self, Vector3(5.5, 0.08, 165), Vector3(i * BLOCK, 0.05, 0), street_mat)
		box(self, Vector3(165, 0.08, 5.5), Vector3(0, 0.055, i * BLOCK), street_mat)

	# Buildings with layered facades, parapets, roofs, awnings and emissive lamps.
	for x in range(-CITY_RADIUS, CITY_RADIUS + 1):
		for z in range(-CITY_RADIUS, CITY_RADIUS + 1):
			if abs(x) <= 1 and abs(z) <= 1:
				continue
			_make_building(x, z)

	_make_market()
	_make_landmarks()
	_make_lamps()
	_make_ambient()

func _make_building(gx:int, gz:int):
	var h := float(rng.randi_range(6, 18))
	var w := float(rng.randi_range(7, 10))
	var d := float(rng.randi_range(7, 10))
	var pos := Vector3(gx * BLOCK, h * 0.5, gz * BLOCK)
	var root_node := Node3D.new()
	root_node.name = "Building_%d_%d" % [gx, gz]
	root_node.position = pos
	add_child(root_node)

	var palette = [
		Color("#a99072"), Color("#8c7660"), Color("#b7a082"),
		Color("#6f655b"), Color("#9d8068"), Color("#c0a98a")
	]
	var base_mat := mat(palette[rng.randi_range(0, palette.size()-1)], 0.88)
	box(root_node, Vector3(w,h,d), Vector3.ZERO, base_mat, true)

	# Roof/parapet.
	var roof_mat := mat(base_mat.albedo_color.darkened(0.18), 0.9)
	box(root_node, Vector3(w+0.25,0.35,d+0.25), Vector3(0,h*0.5+0.18,0), roof_mat)
	for sx in [-1,1]:
		box(root_node, Vector3(0.35,0.7,d+0.5), Vector3(sx*(w*0.5-0.18),h*0.5+0.45,0), roof_mat)

	# Windows: shallow dark recess + warm inner plane.
	var window_mat := mat(Color("#252329"), 0.55)
	var glow_mat := mat(Color("#e4b66c"), 0.35)
	glow_mat.emission_enabled = true
	glow_mat.emission = Color("#e4a34d")
	glow_mat.emission_energy_multiplier = 1.2

	var rows := max(1, int(h / 3.0))
	for row in range(rows):
		var yy := -h*0.5 + 2.0 + row*2.8
		if yy > h*0.42: break
		for side in [-1,1]:
			for col in range(2):
				var xx := -w*0.27 + col*w*0.54
				var zoff := side*(d*0.5+0.03)
				var win := box(root_node, Vector3(1.0,1.45,0.08), Vector3(xx,yy,zoff), window_mat)
				if rng.randf() > 0.28:
					var pane := box(root_node, Vector3(0.72,1.05,0.04), Vector3(xx,yy,zoff+side*0.05), glow_mat)

	# Ground awning.
	if rng.randf() > 0.35:
		var awning_mat := mat(Color("#6c3d32"), 0.9)
		box(root_node, Vector3(w*0.72,0.12,1.0), Vector3(0,-h*0.5+2.0,d*0.5+0.6), awning_mat)

	# Rooftop clutter.
	for k in range(rng.randi_range(1,3)):
		var chimney := mat(Color("#57483e"),0.95)
		var cx := rng.randf_range(-w*0.3,w*0.3)
		var cz := rng.randf_range(-d*0.3,d*0.3)
		box(root_node, Vector3(0.7,1.4,0.7), Vector3(cx,h*0.5+0.9,cz), chimney)

func _make_market():
	var root_node := Node3D.new()
	root_node.name = "NightMarket"
	root_node.position = Vector3(0,0,-BLOCK*2)
	add_child(root_node)
	var wood := mat(Color("#4b3529"),0.9)
	var cloths = [Color("#7b3f3b"),Color("#40576c"),Color("#8b6a3d"),Color("#5b714d")]
	for i in range(9):
		var p := Vector3((i%3-1)*5.0,0.8,(i/3)*4.0)
		box(root_node,Vector3(3.4,1.6,2.2),p,wood)
		box(root_node,Vector3(4.0,0.12,2.8),p+Vector3(0,2.0,0),mat(cloths[i%cloths.size()],0.95))
		for sx in [-1,1]:
			box(root_node,Vector3(0.12,2.0,0.12),p+Vector3(sx*1.7,1.0,0),wood)

func _make_landmarks():
	var tower_mat := mat(Color("#776a5d"),0.9)
	var tower := Node3D.new()
	tower.name = "WatchTower"
	tower.position = Vector3(0,0,BLOCK*5)
	add_child(tower)
	box(tower,Vector3(8,26,8),Vector3(0,13,0),tower_mat,true)
	box(tower,Vector3(10,0.6,10),Vector3(0,26.2,0),mat(Color("#5a5048"),0.95))
	for i in range(4):
		var a := i*PI/2.0
		box(tower,Vector3(0.8,3.0,0.8),Vector3(cos(a)*3.4,27.5,sin(a)*3.4),tower_mat)

func _make_lamps():
	var glow := mat(Color("#d9a45c"),0.25)
	glow.emission_enabled = true
	glow.emission = Color("#d89a4e")
	glow.emission_energy_multiplier = 2.0
	for x in range(-CITY_RADIUS, CITY_RADIUS+1, 2):
		for z in range(-CITY_RADIUS, CITY_RADIUS+1, 2):
			if (x+z)%2 == 0:
				var p := Vector3(x*BLOCK*0.5,2.6,z*BLOCK*0.5)
				box(self,Vector3(0.18,4.5,0.18),p-Vector3(0,2.2,0),mat(Color("#25201c"),0.9))
				var lamp := MeshInstance3D.new()
				var sphere := SphereMesh.new()
				sphere.radius=0.3; sphere.height=0.6
				lamp.mesh=sphere; lamp.position=p; lamp.material_override=glow
				add_child(lamp)

func _make_ambient():
	var env_node := get_node_or_null("WorldEnvironment")
	if env_node and env_node.environment:
		env_node.environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
		env_node.environment.ambient_light_color = Color("#8a8194")
		env_node.environment.ambient_light_energy = 0.45
