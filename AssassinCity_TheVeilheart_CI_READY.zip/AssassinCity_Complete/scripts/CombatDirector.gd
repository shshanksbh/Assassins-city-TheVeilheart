extends Node
## CombatDirector
## Original Identity-inspired mobile sword-combat state machine.
## Uses animation-state names so authored skeletal clips can be dropped in later.

signal attack_started(state_name)
signal attack_finished(state_name)
signal parry_success
signal counter_ready
signal execution_ready
signal combo_changed(index)

enum State {
	IDLE,
	LIGHT_1,
	LIGHT_2,
	LIGHT_3,
	HEAVY,
	DIRECTIONAL_LEFT,
	DIRECTIONAL_RIGHT,
	DIRECTIONAL_FORWARD,
	PARRY,
	COUNTER,
	DODGE_ATTACK,
	GUARD_BREAK,
	EXECUTION,
	AERIAL_ATTACK,
	ASSASSINATION,
	HIT,
	DEAD
}

var state: State = State.IDLE
var combo_index := 0
var combo_window := 0.0
var state_time := 0.0
var parry_window := 0.0
var counter_window := 0.0
var attack_cooldown := 0.0
var target: Node3D

const COMBO_RESET := 0.85
const PARRY_WINDOW := 0.22
const COUNTER_WINDOW := 0.65
const ATTACK_COOLDOWN := 0.12

var animation_map := {
	State.LIGHT_1: "sword_light_01",
	State.LIGHT_2: "sword_light_02",
	State.LIGHT_3: "sword_light_03",
	State.HEAVY: "sword_heavy_01",
	State.DIRECTIONAL_LEFT: "sword_directional_left",
	State.DIRECTIONAL_RIGHT: "sword_directional_right",
	State.DIRECTIONAL_FORWARD: "sword_directional_forward",
	State.PARRY: "sword_parry",
	State.COUNTER: "sword_counter",
	State.DODGE_ATTACK: "sword_dodge_attack",
	State.GUARD_BREAK: "sword_guard_break",
	State.EXECUTION: "sword_execution",
	State.AERIAL_ATTACK: "sword_aerial_attack",
	State.ASSASSINATION: "sword_assassination"
}

func _process(delta):
	state_time += delta
	combo_window = maxf(0.0, combo_window - delta)
	parry_window = maxf(0.0, parry_window - delta)
	counter_window = maxf(0.0, counter_window - delta)
	attack_cooldown = maxf(0.0, attack_cooldown - delta)

	if combo_window <= 0.0 and state in [State.LIGHT_1, State.LIGHT_2]:
		combo_index = 0
		if state_time > 0.35:
			_set_state(State.IDLE)

	if counter_window <= 0.0 and state == State.PARRY:
		_set_state(State.IDLE)

func light_attack():
	if attack_cooldown > 0.0:
		return false
	if state == State.LIGHT_1 and combo_window > 0.0:
		combo_index = 2
		_set_state(State.LIGHT_2)
	elif state == State.LIGHT_2 and combo_window > 0.0:
		combo_index = 3
		_set_state(State.LIGHT_3)
	else:
		combo_index = 1
		_set_state(State.LIGHT_1)
	combo_window = COMBO_RESET
	attack_cooldown = ATTACK_COOLDOWN
	combo_changed.emit(combo_index)
	return true

func heavy_attack():
	if attack_cooldown > 0.0:
		return false
	_set_state(State.HEAVY)
	attack_cooldown = ATTACK_COOLDOWN
	return true

func directional_attack(direction: Vector2):
	if attack_cooldown > 0.0:
		return false
	if absf(direction.x) > absf(direction.y):
		_set_state(State.DIRECTIONAL_RIGHT if direction.x > 0.0 else State.DIRECTIONAL_LEFT)
	else:
		_set_state(State.DIRECTIONAL_FORWARD)
	attack_cooldown = ATTACK_COOLDOWN
	return true

func begin_parry():
	_set_state(State.PARRY)
	parry_window = PARRY_WINDOW
	counter_window = COUNTER_WINDOW

func receive_attack(is_unblockable := false):
	if state == State.PARRY and parry_window > 0.0 and not is_unblockable:
		parry_success.emit()
		counter_ready.emit()
		counter_window = COUNTER_WINDOW
		return "parried"
	if is_unblockable:
		return "dodge_required"
	return "blocked"

func counter_attack():
	if state == State.PARRY and counter_window > 0.0:
		_set_state(State.COUNTER)
		counter_window = 0.0
		return true
	return false

func dodge_attack():
	_set_state(State.DODGE_ATTACK)
	return true

func guard_break():
	_set_state(State.GUARD_BREAK)
	return true

func execute():
	_set_state(State.EXECUTION)
	execution_ready.emit()
	return true

func aerial_attack():
	_set_state(State.AERIAL_ATTACK)
	return true

func assassination():
	_set_state(State.ASSASSINATION)
	return true

func hit_reaction():
	_set_state(State.HIT)

func die():
	_set_state(State.DEAD)

func _set_state(next_state: State):
	state = next_state
	state_time = 0.0
	if animation_map.has(state):
		attack_started.emit(animation_map[state])
	# State timing is deliberately short and animation-driven later.
	if state in [State.HEAVY, State.DIRECTIONAL_LEFT, State.DIRECTIONAL_RIGHT,
		State.DIRECTIONAL_FORWARD, State.COUNTER, State.DODGE_ATTACK,
		State.GUARD_BREAK, State.EXECUTION, State.AERIAL_ATTACK, State.ASSASSINATION]:
		get_tree().create_timer(0.48).timeout.connect(_finish_attack.bind(state))

func _finish_attack(finished_state: State):
	if state == finished_state:
		attack_finished.emit(animation_map.get(finished_state, "combat_idle"))
		_set_state(State.IDLE)
