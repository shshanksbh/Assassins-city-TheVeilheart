extends Control
## Round mobile movement joystick. Feeds the same movement actions used by keyboard.

var finger := -1
var center := Vector2.ZERO
var knob := Vector2.ZERO
var radius := 92.0
var knob_radius := 34.0

func _ready() -> void:
    mouse_filter = Control.MOUSE_FILTER_STOP
    center = size * 0.5
    knob = center
    queue_redraw()

func _notification(what):
    if what == NOTIFICATION_RESIZED:
        center = size * 0.5
        if finger == -1: knob = center
        queue_redraw()

func _draw() -> void:
    draw_circle(center, radius, Color(0.03,0.04,0.05,0.38))
    draw_arc(center, radius, 0, TAU, 64, Color(0.8,0.82,0.86,0.55), 3.0)
    draw_circle(knob, knob_radius, Color(0.75,0.77,0.82,0.72))
    draw_arc(knob, knob_radius, 0, TAU, 48, Color(1,1,1,0.75), 2.0)

func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed and finger == -1 and get_global_rect().has_point(event.position):
            finger = event.index
            _set_knob(event.position)
            get_viewport().set_input_as_handled()
        elif not event.pressed and event.index == finger:
            finger = -1
            _reset()
            get_viewport().set_input_as_handled()
    elif event is InputEventScreenDrag and event.index == finger:
        _set_knob(event.position)
        get_viewport().set_input_as_handled()

func _set_knob(screen_pos: Vector2) -> void:
    var local := to_local(screen_pos)
    var delta := local - center
    if delta.length() > radius: delta = delta.normalized() * radius
    knob = center + delta
    var v := delta / radius
    _set_actions(v)
    queue_redraw()

func _set_actions(v: Vector2) -> void:
    var player := get_tree().get_first_node_in_group("player")
    if player and player.has_method("set_virtual_move"):
        player.set_virtual_move(v)
    _set_action("move_left", v.x < -0.18)
    _set_action("move_right", v.x > 0.18)
    _set_action("move_forward", v.y < -0.18)
    _set_action("move_back", v.y > 0.18)

func _set_action(action: StringName, pressed: bool) -> void:
    if pressed:
        Input.action_press(action)
    else:
        Input.action_release(action)

func _reset() -> void:
    var player := get_tree().get_first_node_in_group("player")
    if player and player.has_method("set_virtual_move"):
        player.set_virtual_move(Vector2.ZERO)
    for a in [&"move_left", &"move_right", &"move_forward", &"move_back"]: Input.action_release(a)
    knob = center
    queue_redraw()
