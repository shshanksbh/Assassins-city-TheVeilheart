extends Node
## Mission state machine for the 15-mission campaign.

signal objective_changed(title, description)
signal mission_completed(number)

var game: Node
var stage := "start"
var target_eliminated := false
var evidence := 0
var witnesses := 0

func setup(g: Node) -> void:
    game = g
    call_deferred("refresh")

func refresh() -> void:
    if not game: return
    var m = game.mission
    var data = game.missions[m-1]
    objective_changed.emit(data[0], data[1])

func on_assassination() -> void:
    target_eliminated = true
    if game and game.mission in [2,7,13]:
        stage = "escape"
        game.set_music_state("escape")
        objective_changed.emit("ESCAPE", "Break the pursuit and reach the safe rooftop.")

func on_evidence(amount := 1) -> void:
    evidence += amount
    if game and game.mission in [3,4,5,6,9,11,14]:
        stage = "complete"
        complete_current()

func on_witness() -> void:
    witnesses += 1
    if game and game.mission == 9 and witnesses >= 3:
        complete_current()

func reach_escape() -> void:
    if stage == "escape": complete_current()

func complete_current() -> void:
    if not game: return
    stage = "complete"
    mission_completed.emit(game.mission)
    game.next_mission()
    refresh()
