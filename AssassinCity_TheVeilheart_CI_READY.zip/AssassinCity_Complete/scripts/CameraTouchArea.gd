extends Control
## Right-side swipe camera control for Android.

var finger := -1
var last := Vector2.ZERO
var sensitivity := 0.006

func _ready() -> void:
    mouse_filter = Control.MOUSE_FILTER_STOP

func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed and finger == -1 and get_global_rect().has_point(event.position):
            finger = event.index
            last = event.position
            get_viewport().set_input_as_handled()
        elif not event.pressed and event.index == finger:
            finger = -1
            get_viewport().set_input_as_handled()
    elif event is InputEventScreenDrag and event.index == finger:
        var d := event.position - last
        last = event.position
        var player := get_tree().get_first_node_in_group("player")
        if player and player.has_method("camera_swipe"):
            player.camera_swipe(d * sensitivity)
        get_viewport().set_input_as_handled()
