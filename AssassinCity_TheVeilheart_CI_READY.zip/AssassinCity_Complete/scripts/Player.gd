extends CharacterBody3D
## Final mobile player controller foundation.
@export var walk_speed := 4.2
@export var sprint_speed := 8.6
@export var acceleration := 22.0
@export var gravity := 21.0
@export var auto_block := true
@export var jump_velocity := 7.2

var move_input := Vector2.ZERO
var camera_yaw := 0.0
var camera_pitch := -0.22
var camera: Camera3D
var combat: Node

func _ready():
	camera = get_node_or_null("Camera3D")
	combat = get_node_or_null("CombatDirector")
	if camera == null:
		camera = Camera3D.new()
		camera.position = Vector3(0, 2.2, 5.8)
		add_child(camera)
		camera.current = true

func set_move_input(v: Vector2):
	move_input = v.clamp(Vector2(-1,-1), Vector2(1,1))

func set_camera_delta(v: Vector2):
	camera_yaw -= v.x * 0.006
	camera_pitch = clampf(camera_pitch - v.y * 0.004, -0.9, 0.35)
	rotation.y = camera_yaw
	camera.rotation.x = camera_pitch

func _physics_process(delta):
	if not is_on_floor():
		velocity.y -= gravity * delta
	else:
		if Input.is_action_just_pressed("ui_accept"):
			velocity.y = jump_velocity

	var input := move_input
	var speed := sprint_speed if input.length() >= 0.72 else walk_speed
	var yaw_basis := Basis(Vector3.UP, rotation.y)
	var forward := -yaw_basis.z
	var right := yaw_basis.x
	var dir := right * input.x + forward * input.y
	dir.y = 0.0
	if dir.length() > 0.05:
		dir = dir.normalized()
		velocity.x = move_toward(velocity.x, dir.x * speed, acceleration * delta)
		velocity.z = move_toward(velocity.z, dir.z * speed, acceleration * delta)
		var target_angle := atan2(dir.x, dir.z)
		rotation.y = lerp_angle(rotation.y, target_angle, minf(delta * 8.0,1.0))
	else:
		velocity.x = move_toward(velocity.x, 0.0, acceleration * delta)
		velocity.z = move_toward(velocity.z, 0.0, acceleration * delta)
	move_and_slide()
