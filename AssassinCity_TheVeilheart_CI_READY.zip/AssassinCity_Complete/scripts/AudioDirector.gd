extends Node
## Adaptive audio architecture. Drop original OGG assets into res://assets/audio/ to activate.

var state := "exploration"
var players := {}
var files := {"exploration":"exploration.ogg","stealth":"stealth.ogg","combat":"combat.ogg","escape":"escape.ogg"}

func _ready() -> void:
    for key in files:
        var p := AudioStreamPlayer.new()
        p.name = "Music_" + key
        p.volume_db = -18.0
        add_child(p)
        players[key] = p
        var path = "res://assets/audio/" + files[key]
        var wav_path = "res://assets/audio/" + key + ".wav"
        if ResourceLoader.exists(path):
            p.stream = load(path)
        elif ResourceLoader.exists(wav_path):
            p.stream = load(wav_path)
            p.autoplay = key == state
            p.loop = true

func set_state(s: String) -> void:
    if not players.has(s): return
    state = s
    for key in players:
        var p: AudioStreamPlayer = players[key]
        if key == state and p.stream:
            if not p.playing: p.play()
            p.volume_db = -8.0
        else:
            p.volume_db = -30.0
