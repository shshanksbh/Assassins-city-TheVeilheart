extends SceneTree

const MAIN_SCENE := "res://scenes/Main.tscn"
const SCREENSHOT := "res://ci-artifacts/main-smoke.png"

var frame_count := 0
var main_instance: Node

func _initialize() -> void:
    main_instance = load(MAIN_SCENE).instantiate()
    root.add_child(main_instance)

func _process(_delta: float) -> bool:
    frame_count += 1
    if frame_count == 120:
        var viewport := get_root().get_viewport()
        var image := viewport.get_texture().get_image()
        DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path("res://ci-artifacts"))
        image.save_png(ProjectSettings.globalize_path(SCREENSHOT))
    if frame_count >= 180:
        quit()
    return false
