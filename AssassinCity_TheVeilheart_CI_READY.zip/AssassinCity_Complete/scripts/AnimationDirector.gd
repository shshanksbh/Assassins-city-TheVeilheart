extends Node3D
## Original procedural animation layer inspired by the movement language of mobile stealth-action games.
## It does not use or reproduce third-party animation files.

var state := "idle"
var t := 0.0
var speed_ratio := 0.0
var root: Node3D
var torso: Node3D
var head: Node3D
var arm_l: Node3D
var arm_r: Node3D
var leg_l: Node3D
var leg_r: Node3D
var weapon_arm: Node3D

func setup(target: Node3D) -> void:
    root = target
    torso = target.get_node_or_null("Torso")
    head = target.get_node_or_null("Head")
    arm_l = target.get_node_or_null("ArmL")
    arm_r = target.get_node_or_null("ArmR")
    leg_l = target.get_node_or_null("LegL")
    leg_r = target.get_node_or_null("LegR")
    weapon_arm = target.get_node_or_null("WeaponArm")

func set_state(s: String, ratio := 0.0) -> void:
    state = s
    speed_ratio = clamp(ratio, 0.0, 1.0)

func _process(delta: float) -> void:
    if not root: return
    t += delta
    var phase := t * (7.0 + speed_ratio * 8.0)
    var swing := sin(phase) * (0.25 + speed_ratio * 0.35)
    var opposite := -swing
    if state == "idle":
        _pose(Vector3(0, sin(t*1.8)*0.015, 0), 0.0, 0.0, 0.0)
    elif state == "walk" or state == "jog" or state == "sprint":
        _pose(Vector3(0, abs(sin(phase))*0.025, 0), swing, opposite, swing)
    elif state == "crouch":
        _pose(Vector3(0,-0.32,0), swing*0.45, opposite*0.45, swing*0.35)
    elif state == "block" or state == "parry":
        _pose(Vector3(0,0.02,0), -0.28, -0.28, 0.0)
        if state == "parry":
            root.rotation.y += sin(t*30.0)*0.01
    elif state == "attack":
        var a := sin(min(t*16.0, PI))
        _pose(Vector3(0,0,0), -0.15-a*0.9, 0.15+a*0.2, a*0.55)
    elif state == "assassinate":
        _pose(Vector3(0,-0.05,0), -0.65, 0.25, -0.45)
    elif state == "vault":
        _pose(Vector3(0,0.15,0), -0.55, 0.55, -0.4)
    elif state == "climb":
        _pose(Vector3(0,0.1,0), swing, opposite, swing)
    elif state == "hit":
        _pose(Vector3(0,0,0), 0.35, -0.35, 0.0)
    elif state == "fall":
        _pose(Vector3(0,0,0), 0.8, -0.8, 0.0)

func _pose(offset: Vector3, arm_a: float, arm_b: float, leg_a: float) -> void:
    root.position.y = offset.y
    if torso: torso.rotation.x = lerp(torso.rotation.x, offset.z, 0.12)
    if head: head.rotation.x = lerp(head.rotation.x, -offset.z*0.4, 0.12)
    if arm_l: arm_l.rotation.x = lerp(arm_l.rotation.x, arm_a, 0.18)
    if arm_r: arm_r.rotation.x = lerp(arm_r.rotation.x, arm_b, 0.18)
    if weapon_arm: weapon_arm.rotation.x = lerp(weapon_arm.rotation.x, arm_b, 0.18)
    if leg_l: leg_l.rotation.x = lerp(leg_l.rotation.x, leg_a, 0.18)
    if leg_r: leg_r.rotation.x = lerp(leg_r.rotation.x, -leg_a, 0.18)
