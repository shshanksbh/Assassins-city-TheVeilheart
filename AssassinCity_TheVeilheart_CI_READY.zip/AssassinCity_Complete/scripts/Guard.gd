extends CharacterBody3D
## Original guard AI: patrol, perception, suspicion, investigation, pursuit and combat.

var hp:=100.0
var suspicion:=0.0
var alert:=false
var attack_timer:=0.0
var stunned:=0.0
var investigate_timer:=0.0
var patrol_points:Array[Vector3]=[]
var patrol_index:=0
var speed:=2.5
var chase_speed:=4.1
var vision_range:=11.0
var vision_dot:=0.25

func _ready()->void:
    add_to_group("guards")
    if patrol_points.is_empty(): patrol_points=[global_position,global_position+Vector3(3,0,0),global_position+Vector3(0,0,3)]

func _physics_process(delta:float)->void:
    if stunned>0: stunned-=delta;velocity=Vector3.ZERO;move_and_slide();return
    var p=get_tree().get_first_node_in_group("player")
    if not p: return
    attack_timer=max(0.0,attack_timer-delta)
    var to_p=p.global_position-global_position;var d=to_p.length();var sees=_can_see(p,to_p,d)
    if sees:
        suspicion=min(1.0,suspicion+delta*(0.8 if not p.crouched else .35))
        if suspicion>.65: alert=true
    else: suspicion=max(0,suspicion-delta*.18)
    if alert:
        get_parent().set_music_state("combat")
        if d>1.8:
            velocity=to_p.normalized()*chase_speed;look_at(Vector3(p.global_position.x,global_position.y,p.global_position.z),Vector3.UP)
        else:
            velocity=Vector3.ZERO
            if attack_timer<=0: attack_timer=1.25;p.take_damage(12,global_position,false)
    elif suspicion>.2:
        investigate_timer=2.5;velocity=to_p.normalized()*1.4
    elif investigate_timer>0:
        investigate_timer-=delta;velocity=Vector3.ZERO
    else:
        var target=patrol_points[patrol_index]
        if global_position.distance_to(target)<.5: patrol_index=(patrol_index+1)%patrol_points.size()
        velocity=(target-global_position).normalized()*speed
    move_and_slide()

func _can_see(p:Node3D,to_p:Vector3,d:float)->bool:
    if d>vision_range:return false
    var dir=to_p.normalized();var facing=-global_transform.basis.z
    if facing.dot(dir)<vision_dot:return false
    return true
func is_attacking()->bool:return attack_timer>1.05
func stun(t:float)->void:stunned=t;suspicion=0;alert=false
func take_damage(amount:float)->void:
    hp-=amount
    if hp<=0:
        var m=get_tree().get_first_node_in_group("mission_director")
        if m and m.has_method("on_assassination"): m.on_assassination()
        queue_free()
