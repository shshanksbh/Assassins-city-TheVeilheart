extends CanvasLayer
## Responsive mobile-first HUD for Android and desktop testing.

var root: Control
var mission_label: Label
var status_label: Label
var menu: Panel

func _ready() -> void:
    root = Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(root)
    mission_label = Label.new()
    mission_label.position = Vector2(24, 24)
    mission_label.add_theme_font_size_override("font_size", 20)
    mission_label.add_theme_color_override("font_color", Color(0.92,0.92,0.88))
    mission_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(mission_label)
    status_label = Label.new()
    status_label.position = Vector2(24, 84)
    status_label.add_theme_font_size_override("font_size", 17)
    status_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(status_label)
    _add_joystick()
    _add_camera_area()
    _add_action_buttons()
    _add_pause_and_cheats()
    var md = get_parent().get_node_or_null("MissionDirector")
    if md and md.has_signal("objective_changed"):
        md.objective_changed.connect(_on_objective)
    _refresh()

func _process(_d: float) -> void:
    _refresh()

func _refresh() -> void:
    var g = get_parent()
    if not g or not g.has_node("Player"):
        return
    var p = g.get_node("Player")
    mission_label.text = "ASSASSIN CITY  •  CHAPTER %d / MISSION %d\n%s" % [g.chapter, g.mission, g.missions[g.mission-1][0]]
    status_label.text = "HP %d   STAMINA %d   VEILHEART %d%%   COINS %d" % [int(p.health), int(p.stamina), int(g.veilheart_charge), g.money]

func _on_objective(title, desc) -> void:
    status_label.text = str(title) + "\n" + str(desc)

func _add_joystick() -> void:
    var j = preload("res://scripts/VirtualJoystick.gd").new()
    j.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
    j.position = Vector2(28, -248)
    j.size = Vector2(220, 220)
    root.add_child(j)

func _add_camera_area() -> void:
    var c = preload("res://scripts/CameraTouchArea.gd").new()
    c.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
    c.position = Vector2(-560, -690)
    c.size = Vector2(500, 400)
    root.add_child(c)

func _add_action_buttons() -> void:
    _add_touch_button("⚔", Vector2(-110,-120), "attack")
    _add_touch_button("↑", Vector2(-220,-120), "jump")
    _add_touch_button("🧎", Vector2(-330,-120), "crouch")
    _add_touch_button("◉", Vector2(-220,-230), "relic")
    _add_touch_button("🛡", Vector2(-110,-230), "block")
    _add_touch_button("↗", Vector2(-330,-230), "dodge")

func _add_touch_button(text_: String, offset: Vector2, action: String) -> void:
    var b = Button.new()
    b.text = text_
    b.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
    b.position = offset
    b.size = Vector2(86, 86)
    b.add_theme_font_size_override("font_size", 28)
    b.button_down.connect(func(): Input.action_press(action))
    b.button_up.connect(func(): Input.action_release(action))
    root.add_child(b)

func _add_pause_and_cheats() -> void:
    var pause = Button.new()
    pause.text = "☰"
    pause.set_anchors_preset(Control.PRESET_TOP_LEFT)
    pause.position = Vector2(24, 150)
    pause.size = Vector2(64, 48)
    pause.pressed.connect(_toggle_menu)
    root.add_child(pause)
    var cheat = Button.new()
    cheat.text = "☠ CHEATS"
    cheat.set_anchors_preset(Control.PRESET_TOP_RIGHT)
    cheat.position = Vector2(-170, 24)
    cheat.size = Vector2(146, 48)
    cheat.pressed.connect(_toggle_cheats)
    root.add_child(cheat)

func _toggle_cheats() -> void:
    _toggle_panel("CHEATS")

func _toggle_menu() -> void:
    _toggle_panel("SETTINGS")

func _toggle_panel(kind: String) -> void:
    if menu:
        menu.queue_free()
        menu = null
        return
    menu = Panel.new()
    menu.set_anchors_preset(Control.PRESET_CENTER)
    menu.position = Vector2(-250, -280)
    menu.size = Vector2(500, 560)
    root.add_child(menu)
    var v = VBoxContainer.new()
    v.position = Vector2(20,20)
    v.size = Vector2(460,520)
    menu.add_child(v)
    var title = Label.new()
    title.text = kind
    title.add_theme_font_size_override("font_size",24)
    v.add_child(title)
    if kind == "CHEATS":
        for o in [["Unlimited Money","unlimited_money"],["God Mode","god_mode"],["Infinite Stamina","infinite_stamina"],["Unlock All Weapons","unlock_weapons"],["Unlock All Skills","unlock_skills"]]:
            var c = CheckButton.new()
            c.text = o[0]
            c.button_pressed = get_parent().cheats[o[1]]
            c.toggled.connect(func(_x): get_parent().use_cheat(o[1]))
            v.add_child(c)
        for o in [["Restore Full Health","full_health"],["+100,000 Coins","money"],["Fill Veilheart Charge","relic"]]:
            var b = Button.new()
            b.text = o[0]
            b.pressed.connect(func(): get_parent().use_cheat(o[1]))
            v.add_child(b)
    else:
        var p = Label.new()
        p.text = "POCO F7 High preset • 60 FPS target\nAuto-block: ON\nAuto-parkour: ON\nMobile renderer: ON"
        v.add_child(p)
        var save = Button.new(); save.text = "SAVE GAME"; save.pressed.connect(func(): get_parent().save_game()); v.add_child(save)
        var health = Button.new(); health.text = "Upgrade Health (250)"; health.pressed.connect(func(): get_parent().buy_health()); v.add_child(health)
        var stam = Button.new(); stam.text = "Upgrade Stamina (250)"; stam.pressed.connect(func(): get_parent().buy_stamina()); v.add_child(stam)
