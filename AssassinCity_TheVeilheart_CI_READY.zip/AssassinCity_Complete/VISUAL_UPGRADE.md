# Visual Upgrade v7
Target device: POCO F7 personal-use preset.

Current procedural improvements:
- 30 multi-storey buildings with varied dimensions
- parapets, windows, awnings and chimneys
- market stalls
- sky gradient, ACES tone mapping, glow and fog
- directional sun + secondary light
- detailed procedural assassin silhouette
- distinct guard silhouette
- metal/roughness materials
- camera foundation

Performance strategy:
- procedural meshes are intentionally low-poly
- hero materials use a small number of draw calls
- distant props should use LOD1/LOD2 in a future asset pass
- shadows capped to 65m
- mobile GL compatibility renderer
