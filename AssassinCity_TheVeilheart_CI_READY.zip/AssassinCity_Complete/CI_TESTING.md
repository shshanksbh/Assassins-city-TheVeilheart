# Assassin City CI testing

This project now contains an automated GitHub Actions validation pipeline.

The pipeline is designed to run **before an APK is handed to the player**:

1. Install the pinned Godot 4.7.2 toolchain.
2. Import the project.
3. Parse-check every GDScript file.
4. Configure the Android SDK/NDK required by Godot 4.7 Android export.
5. Export a debug Android APK.
6. Start the game under a virtual display and capture a smoke-test screenshot.
7. Upload the APK, logs and screenshot as workflow artifacts, even when a step fails.

A failed validation means the build should not be treated as a working build.

The visual smoke test is intentionally only a first-line check. It can confirm that the project starts and produces a frame, but it cannot prove that every touch control or gameplay mechanic works on a physical POCO F7. Device testing is still required for those items.
