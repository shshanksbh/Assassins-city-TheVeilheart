# Assassin City: The Veilheart — Complete Game Project

Godot 4 project designed as a complete playable framework for Android.

SYSTEMS
- 5 story chapters / 15 mission definitions
- Third-person movement and camera
- Sprint, crouch, jump and parkour hooks
- Auto-block by default
- Perfect parry and counter window
- Dodge/escape hooks
- Hidden blade, sword, sabre, throwing knives, smoke bomb
- Health, stamina and weapon progression
- Veilheart powers: Echo, Dominion, Veilstep, Memory
- Guard detection, suspicion, pursuit and combat
- Assassination and escape mission states
- Adaptive music state manager hooks
- Graphics presets including POCO F7 profile
- FPS/resolution/shadow/fog/LOD settings
- Cheats: unlimited money, god mode, infinite stamina, unlock weapons/skills, full health, money and relic charge
- Save data for progression/settings

CONTROLS
WASD = movement
Mouse = camera/attack
Right mouse = auto/manual block
Space = jump/parkour
C = crouch
Q = Veilheart
Esc = pause

NOTE
The project uses procedural placeholder geometry and generated materials where finished third-party art/audio assets are not available in this environment. It is not an already compiled APK and does not claim to contain a AAA asset library.

## v11 combat expansion

The sword combat state machine now supports 14 distinct attack/defense animation slots, including 3-hit light chain, heavy, directional, parry, counter, dodge attack, guard break, execution, aerial attack and assassination.
