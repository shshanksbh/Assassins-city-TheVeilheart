# Playable build instructions

## What this package is
This is the Godot 4 source project for Assassin City: The Veilheart. It contains the integrated gameplay prototype, mobile HUD, round movement joystick, right-side swipe camera, combat/auto-block, guards, missions, Veilheart powers, save system, cheats and procedural city.

It is **not an APK** because the build environment used to prepare this package does not include Godot or the Android SDK.

## Run on Windows/Linux/macOS
1. Install Godot 4.3 or newer (4.x; use a stable release).
2. Extract this ZIP.
3. Open the folder `AssassinCity_Complete` in Godot Project Manager.
4. Click **Import** if necessary, then **Run Project**.
5. Keyboard controls: WASD movement, right mouse camera, left mouse attack, right mouse block, Space parkour/jump, C crouch, Q Veilheart, Esc pause.

## Make an Android APK
1. Install Godot 4.x stable.
2. Install the Android SDK and required platform/build-tools through Android Studio or the Android SDK manager.
3. In Godot: Editor > Editor Settings > Export > Android, set the Android SDK path and Java SDK path.
4. Open Project > Export > Add > Android.
5. Use an APK export for a personal test build. For a device build, enable USB debugging on the phone and install the generated APK with `adb install -r <apk-path>`.
6. On the POCO F7, allow installation from the source you used to transfer the APK, then install it.

## Recommended POCO F7 first run
Graphics: High
FPS: 60
Dynamic resolution: ON if available
Shadows: High
View distance: High
Effects: High
Crowd density: Medium
Auto-block: ON
Auto-parkour: ON

## Important
The project still uses procedural placeholder character/environment geometry. The gameplay can be run and tested, but it is not yet the final Assassin's Creed Identity-level art pass. Replace those placeholders with original authored assets to reach the visual target.


## Android editor
Use the native Godot Android editor. The Android editor can export Android projects without separately installing OpenJDK/Android SDK for the standard pre-built template route. Install matching export templates, import this project, then Export > Android.

## v10 control fixes
- Virtual joystick now passes analog magnitude to the player, so pushing farther forward triggers sprint behavior.
- Movement is camera-relative.
- Camera swipe area is separated from the action-button cluster.


## v10 control fixes
- Virtual joystick passes analog magnitude, so pushing farther forward triggers sprint behavior.
- Movement is camera-relative.
- Camera swipe area is separated from the action-button cluster.
