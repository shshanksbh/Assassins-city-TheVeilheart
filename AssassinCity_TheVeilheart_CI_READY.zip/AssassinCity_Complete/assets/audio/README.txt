Audio architecture:
exploration.ogg
stealth.ogg
combat.ogg
escape.ogg

The game director switches layers/states through set_music_state(). Replace these placeholder slots with licensed/original audio assets. No copyrighted Assassin's Creed music is included.
