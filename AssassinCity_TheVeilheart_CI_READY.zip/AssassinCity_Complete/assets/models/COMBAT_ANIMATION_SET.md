# Sword Combat Animation Set

The combat state machine now exposes these original animation slots:

1. sword_light_01 — light slash 1
2. sword_light_02 — light slash 2
3. sword_light_03 — light slash 3 / combo finisher
4. sword_heavy_01 — heavy committed strike
5. sword_directional_left
6. sword_directional_right
7. sword_directional_forward
8. sword_parry
9. sword_counter
10. sword_dodge_attack
11. sword_guard_break
12. sword_execution
13. sword_aerial_attack
14. sword_assassination

Defensive/support clips:
- sword_block_idle
- sword_hit_reaction
- sword_death
- sword_draw
- sword_sheathe

Animation language reference: Assassin's Creed Identity/mobile Assassin's Creed pacing and readability.
All final meshes, rigs, motion data and clips must remain original.
