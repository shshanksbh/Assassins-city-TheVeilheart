# ASSASSIN CITY — THE VEILHEART
## Chapter I — The City That Forgot
The assassin arrives in Qasr-Nadir to eliminate a magistrate. During the escape, a fragment called the Veilheart reacts to the assassin's hidden blade and reveals a memory of a city beneath the city.

## Chapter II — The Buried Archive
Clues lead through markets, cisterns and a sealed archive. The player learns that the old civilization recorded memories inside objects.

## Chapter III — The False Memory
The Veilheart begins showing events that contradict one another. The player discovers that someone has been deliberately altering memories.

## Chapter IV — The Seven Witnesses
Seven people know different fragments of the truth. Some are allies, some are enemies, and none possess the complete story.

## Chapter V — The Veiled Crown
The player reaches the buried chamber beneath Qasr-Nadir. The Veilheart can reveal, suppress or overwrite memories, but using it has consequences. The ending depends on which memories and evidence the player preserved.

The relic is original to this game and is not the Apple of Eden. It is a memory/reality artifact whose abilities expand through story discoveries.
